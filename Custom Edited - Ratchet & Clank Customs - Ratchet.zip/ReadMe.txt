Model made entirley by me, o0DemonBoy0o, with textures ripped from the game. 
If used it would be nice if you credited me for the model for all the hard work I put into it.

Thank you,
          o0DemonBoy0o